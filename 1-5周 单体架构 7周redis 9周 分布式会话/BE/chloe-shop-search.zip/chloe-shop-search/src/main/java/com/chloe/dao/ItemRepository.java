package com.chloe.dao;

import org.springframework.data.elasticsearch.core.ElasticsearchOperations;

public interface ItemRepository extends ElasticsearchOperations {

}
